import { Building2, MapPin, Phone, Mail } from 'lucide-react';

export function Footer() {
  return (
    <footer className="border-t bg-muted/50">
      <div className="container py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Logo & Description */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="bg-primary p-2 rounded-lg">
                <Building2 className="h-5 w-5 text-primary-foreground" />
              </div>
              <div>
                <span className="font-bold">ОСББ "Дворянська 8"</span>
              </div>
            </div>
            <p className="text-sm text-muted-foreground">
              Багатоквартирний житловий будинок в історичному центрі Одеси. 
              Протиаварійні роботи успішно завершено у 2026 році.
            </p>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="font-semibold mb-4">Контакти</h3>
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2 text-muted-foreground">
                <MapPin className="h-4 w-4" />
                <span>вул. Всеволода Змієнка, 8, м. Одеса</span>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Phone className="h-4 w-4" />
                <span>+38 (099) 630-52-65</span>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Mail className="h-4 w-4" />
                <span>zdrokoleg578@gmail.com</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold mb-4">Корисні посилання</h3>
            <div className="space-y-2 text-sm">
              <a href="https://www.minregion.gov.ua/" target="_blank" rel="noopener noreferrer" className="block text-muted-foreground hover:text-foreground">
                Мінрегіон України
              </a>
              <a href="https://zakon.rada.gov.ua/" target="_blank" rel="noopener noreferrer" className="block text-muted-foreground hover:text-foreground">
                Законодавство України
              </a>
              <a href="https://omr.gov.ua/" target="_blank" rel="noopener noreferrer" className="block text-muted-foreground hover:text-foreground">
                Одеська міська рада
              </a>
            </div>
          </div>
        </div>

        <div className="border-t mt-8 pt-4 text-center text-sm text-muted-foreground">
          © 2026 ОСББ "Дворянська 8". Всі права захищені.
        </div>
      </div>
    </footer>
  );
}