import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { MapPin, Phone, Mail, User, Clock, Send, ExternalLink } from 'lucide-react';

const contactInfo = {
  address: 'вул. Всеволода Змієнка, 8, м. Одеса, 65022',
  phone: '+38 (099) 630-52-65',
  email: 'zdrokoleg578@gmail.com',
  head: 'Здрок Олег Вікторович',
  hours: 'Пн-Пт: 09:00-18:00',
};

// Координати будинку (вул. Всеволода Змієнка, 8, Одеса)
const mapCoordinates = {
  lat: 46.4825,
  lng: 30.7233,
};

export function Contacts() {
  return (
    <div className="container py-12">
      <div className="max-w-5xl mx-auto">
        <h1 className="text-4xl font-bold mb-4">Контакти</h1>
        <p className="text-muted-foreground mb-8">Зв'яжіться з нами зручним для вас способом</p>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Contact Info */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Контактна інформація</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start gap-4">
                  <div className="bg-primary/10 p-3 rounded-lg">
                    <MapPin className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">Адреса</p>
                    <p className="text-muted-foreground">{contactInfo.address}</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-primary/10 p-3 rounded-lg">
                    <Phone className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">Телефон</p>
                    <a href={`tel:${contactInfo.phone}`} className="text-primary hover:underline">
                      {contactInfo.phone}
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-primary/10 p-3 rounded-lg">
                    <Mail className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">Email</p>
                    <a href={`mailto:${contactInfo.email}`} className="text-primary hover:underline">
                      {contactInfo.email}
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-primary/10 p-3 rounded-lg">
                    <User className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">Голова ОСББ</p>
                    <p className="text-muted-foreground">{contactInfo.head}</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-primary/10 p-3 rounded-lg">
                    <Clock className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">Години роботи</p>
                    <p className="text-muted-foreground">{contactInfo.hours}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Написати повідомлення</CardTitle>
              </CardHeader>
              <CardContent>
                <form className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <Input placeholder="Ваше ім'я" />
                    <Input placeholder="Телефон" type="tel" />
                  </div>
                  <Input placeholder="Email" type="email" />
                  <Textarea placeholder="Ваше повідомлення..." rows={4} />
                  <Button className="w-full">
                    <Send className="h-4 w-4 mr-2" />
                    Надіслати
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Map */}
          <div className="space-y-6">
            <Card className="overflow-hidden">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Розташування на карті</span>
                  <Button variant="outline" size="sm" asChild>
                    <a 
                      href={`https://www.google.com/maps/search/?api=1&query=${mapCoordinates.lat},${mapCoordinates.lng}`}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <ExternalLink className="h-4 w-4 mr-2" />
                      Відкрити на Картах
                    </a>
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="relative w-full h-[400px]">
                  <iframe
                    src={`https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2747.5!2d${mapCoordinates.lng}!3d${mapCoordinates.lat}!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40c6318b0b7c7c7b%3A0x7c7c7c7c7c7c7c7c!2z0LLRg9C70LjRhtGPINCS0LXRgNGC0L7QstCw0LvQsCDQl9C40LbQu9C10LrQsCwgOCwg0J7QtNC10YHRjCwg0J7QtNC10YHRjNC60LAg0L7QsdC70LDRgdGC0YwsIDY1MDAw!5e0!3m2!1suk!2sua!4v1609459200000!5m2!1suk!2sua&q=${mapCoordinates.lat},${mapCoordinates.lng}`}
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    allowFullScreen
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Як дістатися</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm text-muted-foreground">
                  <p>
                    <strong className="text-foreground">Громадський транспорт:</strong>
                    <br />
                    Трамваї: 5, 12, 28 (зупинка "вул. Дворянська")
                    <br />
                    Автобуси: 117, 137, 150
                  </p>
                  <p>
                    <strong className="text-foreground">Орієнтир:</strong>
                    <br />
                    Будинок розташований поруч з ТЦ "Галерея Афіна" та Одеським Спасо-Преображенським собором.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}