import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Phone, Mail, User, Building, FileText, Users, Droplets, Lightbulb, Flame, Trash2, Car, TreePine, Bug } from 'lucide-react';

const headInfo = {
  name: 'Здрок Олег Вікторович',
  position: 'Голова ОСББ',
  phone: '+38 (099) 630-52-65',
  email: 'zdrokoleg578@gmail.com',
};

const responsibilities = [
  'Загальне керівництво ОСББ',
  'Представництво інтересів співвласників',
  'Організація загальних зборів',
  'Взаємодія з підрядниками та організаціями',
  'Контроль за фінансовою діяльністю',
  'Ведення документації ОСББ',
];

const functions = [
  { icon: Building, title: 'Управління майном', description: 'Управління спільним майном багатоквартирного будинку, утримання та ремонт' },
  { icon: FileText, title: 'Документація', description: 'Ведення технічної документації, паспорта будинку, договорів' },
  { icon: Users, title: 'Збори співвласників', description: 'Організація та проведення загальних зборів співвласників' },
  { icon: Droplets, title: 'Комунальні послуги', description: 'Контроль якості надання комунальних послуг, розподіл платежів' },
];

const services = [
  { icon: Phone, title: 'Аварійна служба ОСББ', description: 'Термінове усунення аварійних ситуацій у будинку', contact: '+38 (099) 630-52-65', badge: 'Терміново', badgeColor: 'bg-red-500', hours: 'Цілодобово' },
  { icon: Droplets, title: 'Водопостачання', description: 'Обслуговування систем водопостачання та водовідведення', contact: '0-800-505-505', hours: 'Пн-Пт: 08:00-17:00' },
  { icon: Lightbulb, title: 'Електропостачання', description: 'Обслуговування електромереж та електрообладнання', contact: '0-800-505-505', hours: 'Цілодобово' },
  { icon: Flame, title: 'Газопостачання', description: 'Обслуговування газових мереж та обладнання', contact: '104', badge: 'Терміново', badgeColor: 'bg-red-500', hours: 'Цілодобово' },
  { icon: Trash2, title: 'Вивезення сміття', description: 'Регулярне вивезення твердих побутових відходів', contact: '+38 (048) 705-67-93', hours: 'Пн, Ср, Пт: 08:00-12:00' },
  { icon: User, title: 'Голова ОСББ', description: 'Загальні питання щодо управління будинком', contact: '+38 (099) 630-52-65', hours: 'Пн-Пт: 09:00-18:00' },
  { icon: Car, title: 'Паркування', description: 'Організація паркування на прибудинковій території', contact: '+38 (099) 630-52-65', hours: 'Пн-Пт: 09:00-18:00' },
  { icon: TreePine, title: 'Благоустрій', description: 'Догляд за прибудинковою територією та озелененням', contact: '+38 (099) 630-52-65', hours: 'Пн-Пт: 09:00-18:00' },
  { icon: Bug, title: 'Дезінсекція', description: 'Боротьба з комахами та гризунами', contact: '+38 (048) 705-67-95', hours: 'За попереднім записом' },
];

const emergencyNumbers = [
  { number: '101', label: 'Пожежна' },
  { number: '102', label: 'Поліція' },
  { number: '103', label: 'Швидка' },
  { number: '104', label: 'Газова' },
];

export function Management() {
  return (
    <div className="container py-12">
      <div className="max-w-5xl mx-auto">
        <h1 className="text-4xl font-bold mb-8">Управління будинком</h1>
        
        {/* Head Info */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Голова ОСББ</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex items-start gap-4">
                <div className="bg-primary/10 p-4 rounded-full">
                  <User className="h-8 w-8 text-primary" />
                </div>
                <div>
                  <p className="text-lg font-semibold">{headInfo.name}</p>
                  <p className="text-muted-foreground">{headInfo.position}</p>
                  <div className="mt-3 space-y-1">
                    <div className="flex items-center gap-2 text-sm">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <a href={`tel:${headInfo.phone}`} className="text-primary hover:underline">{headInfo.phone}</a>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Mail className="h-4 w-4 text-muted-foreground" />
                      <a href={`mailto:${headInfo.email}`} className="text-primary hover:underline">{headInfo.email}</a>
                    </div>
                  </div>
                </div>
              </div>
              <div>
                <h4 className="font-semibold mb-3">Обов'язки та функції:</h4>
                <ul className="space-y-2">
                  {responsibilities.map((item, index) => (
                    <li key={index} className="flex items-start gap-2 text-sm text-muted-foreground">
                      <span className="text-primary mt-1">•</span>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Functions */}
        <h2 className="text-2xl font-bold mb-4">Основні функції ОСББ</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          {functions.map((func, index) => {
            const Icon = func.icon;
            return (
              <Card key={index}>
                <CardContent className="p-4 flex items-start gap-4">
                  <div className="bg-primary/10 p-3 rounded-lg">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">{func.title}</h4>
                    <p className="text-sm text-muted-foreground">{func.description}</p>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Registration Info */}
        <Card className="mb-8 bg-muted/50">
          <CardContent className="p-6">
            <h4 className="font-semibold mb-4">Реєстрація ОСББ</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-muted-foreground">ЄДРПОУ:</span>
                <span className="ml-2 font-medium">34674154</span>
              </div>
              <div>
                <span className="text-muted-foreground">Юридична адреса:</span>
                <span className="ml-2 font-medium">65022, м. Одеса, вул. Косовська, 2-Д</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Services */}
        <h2 className="text-2xl font-bold mb-4">Служби та послуги</h2>
        <p className="text-muted-foreground mb-6">Комунікації та служби, що обслуговують наш будинок</p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <Card key={index} className="relative">
                {service.badge && (
                  <Badge className={`absolute top-3 right-3 ${service.badgeColor} text-white`}>
                    {service.badge}
                  </Badge>
                )}
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="bg-primary/10 p-2 rounded-lg">
                      <Icon className="h-5 w-5 text-primary" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-semibold text-sm mb-1">{service.title}</h4>
                      <p className="text-xs text-muted-foreground mb-2">{service.description}</p>
                      <a href={`tel:${service.contact}`} className="text-sm text-primary hover:underline block">{service.contact}</a>
                      <p className="text-xs text-muted-foreground mt-1">{service.hours}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Emergency Numbers */}
        <h2 className="text-2xl font-bold mb-4">Екстрені служби</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {emergencyNumbers.map((item, index) => (
            <Card key={index} className="text-center bg-red-50 border-red-200">
              <CardContent className="p-4">
                <a href={`tel:${item.number}`} className="text-2xl font-bold text-red-600 hover:underline block mb-1">
                  {item.number}
                </a>
                <p className="text-sm text-muted-foreground">{item.label}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}