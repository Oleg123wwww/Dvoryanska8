import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MapPin, Calendar, Building, Users, ArrowRight, CheckCircle, FileText, Phone } from 'lucide-react';

const newsItems = [
  {
    id: 1,
    category: 'Ремонт',
    date: '15 березня 2026',
    readTime: '2 хв',
    title: 'Протиаварійні роботи успішно завершено!',
    excerpt: 'Раді повідомити, що всі протиаварійні роботи на даху будинку повністю завершено...',
    image: '/images/news-repair.jpg',
  },
  {
    id: 2,
    category: 'Оголошення',
    date: '1 березня 2026',
    readTime: '2 хв',
    title: 'Мешканці повертаються до відновленого житла',
    excerpt: 'Завершено переселення мешканців після завершення протиаварійних робіт...',
    image: '/images/news-event.jpg',
  },
  {
    id: 3,
    category: 'Фінанси',
    date: '20 лютого 2026',
    readTime: '2 хв',
    title: 'Затверджено кошторис на 2026 рік',
    excerpt: 'Загальні збори співвласників затвердили кошторис ОСББ на поточний рік...',
    image: '/images/news-finance.png',
  },
];

const features = [
  {
    icon: Building,
    title: 'Історична цінність',
    description: 'Пам\'ятка містобудування та архітектури місцевого значення, збудована у 1887 році',
  },
  {
    icon: CheckCircle,
    title: 'Під охороною держави',
    description: 'Внесено до Державного реєстру нерухомих пам\'яток України, охоронний №209-ОД',
  },
  {
    icon: Users,
    title: 'Житловий фонд',
    description: '4-поверховий будинок з підвалом та неексплуатованим горищем',
  },
  {
    icon: FileText,
    title: 'Спільнота',
    description: 'Об\'єднання співвласників для ефективного управління будинком',
  },
];

const stats = [
  { value: '1887', label: 'Рік побудови' },
  { value: '4', label: 'Поверхи' },
  { value: '168', label: 'Мешканців' },
  { value: '2026', label: 'Рік відновлення' },
];

export function Home() {
  return (
    <div>
      {/* Hero Section */}
      <section className="relative min-h-[600px] flex items-center">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: 'url(/building-photo.jpg)' }}
        >
          <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/80 to-background/40" />
        </div>
        
        <div className="container relative z-10 py-16">
          <div className="max-w-3xl mx-auto text-center">
            <Badge className="mb-4 bg-green-500/20 text-green-700 hover:bg-green-500/30">
              <CheckCircle className="h-3 w-3 mr-1" />
              Відновлення завершено у 2026 році
            </Badge>
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4">
              ОСББ
              <span className="block text-primary">"Дворянська 8"</span>
            </h1>
            
            <p className="text-lg text-muted-foreground mb-8">
              Багатоквартирний житловий будинок в історичному центрі Одеси. 
              Протиаварійні роботи успішно завершено, мешканці повернулися до житла.
            </p>
            
            <div className="flex flex-wrap justify-center gap-4 mb-8">
              <Card className="bg-background/80 backdrop-blur">
                <CardContent className="p-4 flex items-center gap-3">
                  <MapPin className="h-5 w-5 text-primary" />
                  <div>
                    <p className="text-xs text-muted-foreground">Адреса</p>
                    <p className="text-sm font-medium">вул. Всеволода Змієнка, 8</p>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-background/80 backdrop-blur">
                <CardContent className="p-4 flex items-center gap-3">
                  <Calendar className="h-5 w-5 text-primary" />
                  <div>
                    <p className="text-xs text-muted-foreground">Рік побудови</p>
                    <p className="text-sm font-medium">1887 рік</p>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-background/80 backdrop-blur">
                <CardContent className="p-4 flex items-center gap-3">
                  <Building className="h-5 w-5 text-primary" />
                  <div>
                    <p className="text-xs text-muted-foreground">Поверховість</p>
                    <p className="text-sm font-medium">4 поверхи + підвал</p>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="flex flex-wrap justify-center gap-4">
              <Button asChild size="lg">
                <Link to="/about">
                  Дізнатися більше
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Link>
              </Button>
              <Button variant="outline" size="lg" asChild>
                <Link to="/contacts">
                  <Phone className="h-4 w-4 mr-2" />
                  Зв\'язатися з нами
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 bg-muted/50">
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-primary mb-1">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Про наш будинок</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Історія та сьогодення багатоквартирного житлового будинку з багатою історією в серці Одеси
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index} className="h-full">
                  <CardContent className="p-6">
                    <div className="bg-primary/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                      <Icon className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="font-semibold mb-2">{feature.title}</h3>
                    <p className="text-sm text-muted-foreground">{feature.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* News Section */}
      <section className="py-16 bg-muted/50">
        <div className="container">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-3xl font-bold mb-2">Новини та оновлення</h2>
              <p className="text-muted-foreground">Останні новини ОСББ</p>
            </div>
            <Button variant="outline" asChild>
              <Link to="/news">Всі новини</Link>
            </Button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {newsItems.map((news) => (
              <Card key={news.id} className="overflow-hidden group cursor-pointer">
                <div className="aspect-video overflow-hidden">
                  <img 
                    src={news.image} 
                    alt={news.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <CardContent className="p-6">
                  <div className="flex items-center gap-2 mb-3">
                    <Badge variant="secondary">{news.category}</Badge>
                    <span className="text-xs text-muted-foreground">{news.date}</span>
                    <span className="text-xs text-muted-foreground">{news.readTime}</span>
                  </div>
                  <h3 className="font-semibold mb-2 line-clamp-2">{news.title}</h3>
                  <p className="text-sm text-muted-foreground line-clamp-2">{news.excerpt}</p>
                  <div className="flex items-center justify-between mt-4">
                    <span className="text-sm text-muted-foreground">Голова ОСББ</span>
                    <Button variant="ghost" size="sm" className="text-primary">
                      Читати
                      <ArrowRight className="h-4 w-4 ml-1" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}