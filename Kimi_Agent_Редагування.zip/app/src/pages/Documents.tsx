import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Download, FileText, FileSpreadsheet, FileCheck, FileArchive } from 'lucide-react';

const documents = [
  {
    id: 1,
    title: 'Статут ОСББ',
    description: 'Основний документ, що регламентує діяльність об\'єднання співвласників',
    fileName: 'statut-osbb.pdf',
    size: '245 KB',
    date: '15.03.2026',
    icon: FileCheck,
    category: 'Установчі',
  },
  {
    id: 2,
    title: 'Протокол зборів 2026',
    description: 'Протокол загальних зборів співвласників від 15 березня 2026 року',
    fileName: 'protokol-zboriv-2026.pdf',
    size: '189 KB',
    date: '15.03.2026',
    icon: FileText,
    category: 'Протоколи',
  },
  {
    id: 3,
    title: 'Кошторис на 2026 рік',
    description: 'Затверджений кошторис ОСББ на поточний рік',
    fileName: 'koshtoris-2026.pdf',
    size: '156 KB',
    date: '15.03.2026',
    icon: FileSpreadsheet,
    category: 'Фінанси',
  },
  {
    id: 4,
    title: 'Договір на управління',
    description: 'Договір про надання послуг з управління багатоквартирним будинком',
    fileName: 'dogovir-upravlinnya.pdf',
    size: '198 KB',
    date: '01.01.2026',
    icon: FileCheck,
    category: 'Договори',
  },
  {
    id: 5,
    title: 'Правила проживання',
    description: 'Правила проживання в багатоквартирному будинку ОСББ',
    fileName: 'pravyla-prozhyvannya.pdf',
    size: '178 KB',
    date: '15.03.2026',
    icon: FileArchive,
    category: 'Правила',
  },
];

export function Documents() {
  return (
    <div className="container py-12">
      <div className="max-w-5xl mx-auto">
        <h1 className="text-4xl font-bold mb-4">Документи</h1>
        <p className="text-muted-foreground mb-8">Офіційні документи ОСББ "Дворянська 8"</p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {documents.map((doc) => {
            const Icon = doc.icon;
            return (
              <Card key={doc.id} className="group hover:shadow-lg transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="bg-primary/10 p-3 rounded-lg">
                      <Icon className="h-6 w-6 text-primary" />
                    </div>
                    <Badge variant="secondary">{doc.category}</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <h3 className="font-semibold mb-2">{doc.title}</h3>
                  <p className="text-sm text-muted-foreground mb-4">{doc.description}</p>
                  <div className="flex items-center justify-between text-xs text-muted-foreground mb-4">
                    <span>{doc.size}</span>
                    <span>Оновлено: {doc.date}</span>
                  </div>
                  <Button className="w-full" asChild>
                    <a href={`/documents/${doc.fileName}`} download>
                      <Download className="h-4 w-4 mr-2" />
                      Завантажити
                    </a>
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <Card className="mt-8 bg-blue-50 border-blue-200">
          <CardContent className="p-6">
            <h3 className="font-semibold text-blue-900 mb-2">Потрібен інший документ?</h3>
            <p className="text-sm text-blue-800 mb-4">
              Якщо вам потрібен документ, якого немає в списку, зверніться до голови ОСББ.
            </p>
            <div className="flex items-center gap-4 text-sm text-blue-800">
              <span>Тел: <a href="tel:+380996305265" className="underline">+38 (099) 630-52-65</a></span>
              <span>Email: <a href="mailto:zdrokoleg578@gmail.com" className="underline">zdrokoleg578@gmail.com</a></span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}