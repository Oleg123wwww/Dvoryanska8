import { Card, CardContent } from '@/components/ui/card';
import { Building, MapPin, Calendar, Shield } from 'lucide-react';

export function About() {
  return (
    <div className="container py-12">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-bold mb-8 text-center">Про наш будинок</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <div className="bg-primary/10 p-3 rounded-lg">
                  <MapPin className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Адреса</h3>
                  <p className="text-muted-foreground">вул. Всеволода Змієнка, 8 (Дворянська)</p>
                  <p className="text-muted-foreground">Приморський район, м. Одеса</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <div className="bg-primary/10 p-3 rounded-lg">
                  <Building className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Про об'єкт</h3>
                  <p className="text-muted-foreground">Житловий будинок — чотирьохповерхова будівля з підвалом та неексплуатованим горищем, збудована у 1887 році за проектом архітектора Зелінського Ц.Е.</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="bg-primary/10 p-3 rounded-lg">
                <Calendar className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold mb-2">Історична довідка</h3>
                <p className="text-muted-foreground mb-4">
                  Будівля є пам'яткою культурної спадщини, включена в списки пам'яток містобудівництва і архітектури 
                  місцевого значення та прийнята під охорону держави згідно рішення Одеського облвиконкому 
                  №580 від 27.12.1991 р. Охоронний номер — №209-ОД.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="mb-8 border-green-500/20 bg-green-500/5">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="bg-green-500/20 p-3 rounded-lg">
                <Shield className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <h3 className="font-semibold mb-2 text-green-700">Відновлення завершено (2026)</h3>
                <p className="text-muted-foreground">
                  Внаслідок збройної агресії Російської Федерації будинок зазнав пошкоджень. 
                  У 2026 році всі протиаварійні роботи були успішно завершені. 
                  Всі мешканці повернулися до своїх квартир!
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <h2 className="text-2xl font-bold mb-6">Виконані роботи</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {[
            'Демонтаж пошкодженого покриття покрівлі',
            'Заміна покриття на профнастил (547,4 м²)',
            'Улаштування пароізоляції',
            'Заміна решетування та контр-решетування',
          ].map((work, index) => (
            <Card key={index}>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <div className="bg-primary/10 w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold text-primary">
                    {index + 1}
                  </div>
                  <p className="text-sm">{work}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="text-center">
            <CardContent className="p-6">
              <div className="text-3xl font-bold text-primary mb-1">1887</div>
              <div className="text-sm text-muted-foreground">Рік побудови</div>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="p-6">
              <div className="text-3xl font-bold text-primary mb-1">4</div>
              <div className="text-sm text-muted-foreground">Поверхи</div>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="p-6">
              <div className="text-3xl font-bold text-primary mb-1">168</div>
              <div className="text-sm text-muted-foreground">Мешканців</div>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="p-6">
              <div className="text-3xl font-bold text-primary mb-1">2026</div>
              <div className="text-sm text-muted-foreground">Рік відновлення</div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}