import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ArrowRight, Calendar, Clock, User } from 'lucide-react';

const allNews = [
  {
    id: 1,
    category: 'Ремонт',
    date: '15 березня 2026',
    readTime: '2 хв',
    title: 'Протиаварійні роботи успішно завершено!',
    excerpt: 'Раді повідомити, що всі протиаварійні роботи на даху будинку повністю завершено.',
    fullText: `Шановні мешканці!

Раді повідомити, що всі протиаварійні роботи на даху будинку повністю завершено. Покрівля повністю відновлена, встановлено нове покриття з профнастилу, улаштовано пароізоляцію.

Виконані роботи:
• Демонтаж пошкодженого покриття покрівлі
• Заміна покриття на профнастил (547,4 м²)
• Улаштування пароізоляції
• Заміна решетування та контр-решетування
• Улаштування коньків та карнизних звисів
• Вогнеобробка дерев'яних конструкцій

Всі роботи виконані якісно та в строк. Дякуємо за розуміння та терпіння під час проведення робіт!

З повагою,
Голова ОСББ Здрок О.В.`,
    image: '/images/news-repair.jpg',
    author: 'Голова ОСББ',
  },
  {
    id: 2,
    category: 'Оголошення',
    date: '1 березня 2026',
    readTime: '2 хв',
    title: 'Мешканці повертаються до відновленого житла',
    excerpt: 'Завершено переселення мешканців після завершення протиаварійних робіт.',
    fullText: `Шановні мешканці!

Завершено переселення мешканців після завершення протиаварійних робіт. Всі квартири підготовлені до заселення, комунальні послуги відновлено.

Інформація для мешканців:
• Всі квартири перевірені на придатність до проживання
• Комунальні послуги відновлено в повному обсязі
• Ліфт працює в штатному режимі
• Прибудинкова територія прибрана

Якщо у вас виникли питання щодо заселення, звертайтеся до голови ОСББ за телефоном +38 (099) 630-52-65.

З повагою,
Голова ОСББ Здрок О.В.`,
    image: '/images/news-event.jpg',
    author: 'Голова ОСББ',
  },
  {
    id: 3,
    category: 'Фінанси',
    date: '20 лютого 2026',
    readTime: '2 хв',
    title: 'Затверджено кошторис на 2026 рік',
    excerpt: 'Загальні збори співвласників затвердили кошторис ОСББ на поточний рік.',
    fullText: `Шановні мешканці!

Загальні збори співвласників, що відбулися 15 березня 2026 року, затвердили кошторис ОСББ на поточний рік.

Основні статті витрат:
• Утримання будинку (прибирання) — 120 000 грн
• Електроенергія (МОП) — 85 000 грн
• Водопостачання (МОП) — 45 000 грн
• Ремонтні роботи — 150 000 грн
• Технічне обслуговування ліфта — 35 000 грн
• Дезінсекція/дератизація — 12 000 грн
• Благоустрій прибудинкової території — 25 000 грн
• Непередбачені витрати — 13 000 грн

Загальний обсяг видатків: 485 000 грн

Кошторис доступний для ознайомлення у вкладці "Документи".

З повагою,
Голова ОСББ Здрок О.В.`,
    image: '/images/news-finance.png',
    author: 'Голова ОСББ',
  },
  {
    id: 4,
    category: 'Комунальні послуги',
    date: '10 лютого 2026',
    readTime: '2 хв',
    title: 'Оновлення тарифів на комунальні послуги',
    excerpt: 'Інформуємо про зміни в тарифах на водопостачання та водовідведення.',
    fullText: `Шановні мешканці!

Інформуємо про зміни в тарифах на комунальні послуги. Нові тарифи набувають чинності з 1 березня 2026 року.

Актуальні тарифи:
• Холодне водопостачання — 21.50 грн/м³
• Водовідведення — 20.80 грн/м³
• Електропостачання — 2.88 грн/кВт·год
• Опалення — 38.90 грн/м²
• Вивезення ТПВ — від 48.00 грн/міс

Тарифи встановлено відповідно до постанов НКРЕКП та рішень міської ради.

З повагою,
Голова ОСББ Здрок О.В.`,
    image: '/images/news-utility.jpg',
    author: 'Голова ОСББ',
  },
  {
    id: 5,
    category: 'Заходи',
    date: '5 лютого 2026',
    readTime: '1 хв',
    title: 'День відкритих дверей в ОСББ',
    excerpt: 'Запрошуємо всіх мешканців на зустріч з головою ОСББ.',
    fullText: `Шановні мешканці!

Запрошуємо всіх мешканців на День відкритих дверей в ОСББ.

Дата: 15 березня 2026 року
Час: 14:00 - 17:00
Місце: приміщення ОСББ (вул. Всеволода Змієнка, 8)

На зустрічі обговоримо:
• Плани на 2026 рік
• Питання благоустрою двору
• Фінансову звітність
• Ваші пропозиції та побажання

Чекаємо на вас!

З повагою,
Голова ОСББ Здрок О.В.`,
    image: '/images/news-event.jpg',
    author: 'Голова ОСББ',
  },
  {
    id: 6,
    category: 'Технічне обстеження',
    date: '1 лютого 2026',
    readTime: '3 хв',
    title: 'Результати інженерних досліджень та завершення робіт',
    excerpt: 'Завершено інженерні дослідження та всі відновлювальні роботи.',
    fullText: `Шановні мешканці!

Завершено інженерні дослідження та всі відновлювальні роботи. Будинок повністю готовий до експлуатації.

Результати обстеження:
• Несучі конструкції — в задовільному стані
• Фундамент — без деформацій
• Перекриття — стабільні
• Дах — повністю відновлений
• Інженерні мережі — працездатні

Висновок експертів: будинок придатний для проживання. Всі протиаварійні роботи виконані відповідно до проектної документації.

З повагою,
Голова ОСББ Здрок О.В.`,
    image: '/images/news-inspection.jpg',
    author: 'Голова ОСББ',
  },
];

export function News() {
  const [selectedNews, setSelectedNews] = useState<typeof allNews[0] | null>(null);

  return (
    <div className="container py-12">
      <div className="max-w-5xl mx-auto">
        <h1 className="text-4xl font-bold mb-4">Новини та оновлення</h1>
        <p className="text-muted-foreground mb-8">Останні новини ОСББ "Дворянська 8"</p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {allNews.map((news) => (
            <Card key={news.id} className="overflow-hidden group cursor-pointer hover:shadow-lg transition-shadow">
              <div className="aspect-video overflow-hidden">
                <img 
                  src={news.image} 
                  alt={news.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <CardContent className="p-6">
                <div className="flex items-center gap-2 mb-3">
                  <Badge variant="secondary">{news.category}</Badge>
                </div>
                <div className="flex items-center gap-4 text-xs text-muted-foreground mb-3">
                  <span className="flex items-center gap-1">
                    <Calendar className="h-3 w-3" />
                    {news.date}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {news.readTime}
                  </span>
                </div>
                <h3 className="font-semibold mb-2 line-clamp-2">{news.title}</h3>
                <p className="text-sm text-muted-foreground line-clamp-3 mb-4">{news.excerpt}</p>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground flex items-center gap-1">
                    <User className="h-3 w-3" />
                    {news.author}
                  </span>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="text-primary"
                    onClick={() => setSelectedNews(news)}
                  >
                    Читати
                    <ArrowRight className="h-4 w-4 ml-1" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Dialog for full news */}
        <Dialog open={!!selectedNews} onOpenChange={() => setSelectedNews(null)}>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <div className="aspect-video overflow-hidden rounded-lg mb-4">
                <img 
                  src={selectedNews?.image} 
                  alt={selectedNews?.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex items-center gap-2 mb-2">
                <Badge variant="secondary">{selectedNews?.category}</Badge>
                <span className="text-xs text-muted-foreground flex items-center gap-1">
                  <Calendar className="h-3 w-3" />
                  {selectedNews?.date}
                </span>
              </div>
              <DialogTitle className="text-xl">{selectedNews?.title}</DialogTitle>
            </DialogHeader>
            <div className="mt-4">
              <p className="text-sm text-muted-foreground mb-4 flex items-center gap-1">
                <User className="h-3 w-3" />
                {selectedNews?.author}
              </p>
              <div className="whitespace-pre-line text-sm leading-relaxed">
                {selectedNews?.fullText}
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}