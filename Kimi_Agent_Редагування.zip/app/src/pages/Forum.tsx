import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { MessageSquare, User, Clock, Eye, ArrowLeft, Send, ThumbsUp, MessageCircle } from 'lucide-react';

interface Reply {
  id: number;
  author: string;
  date: string;
  text: string;
  likes: number;
}

interface Topic {
  id: number;
  title: string;
  author: string;
  date: string;
  replies: Reply[];
  views: number;
  category: string;
  lastReply: string;
  content: string;
}

const initialTopics: Topic[] = [
  {
    id: 1,
    title: 'Ремонт даху — питання та відповіді',
    author: 'Марія К.',
    date: '15 березня 2026',
    views: 156,
    category: 'Ремонт',
    lastReply: '2 години тому',
    content: 'Добрий день! Маю питання щодо ремонту даху. Чи буде проводитися додаткова гідроізоляція? І скільки часу гарантія на виконані роботи?',
    replies: [
      {
        id: 1,
        author: 'Голова ОСББ',
        date: '15 березня 2026, 14:30',
        text: 'Добрий день, Маріє! Так, гідроізоляція вже встановлена в рамках протиаварійних робіт. Гарантія на роботи становить 5 років. Всі деталі можна знайти в акті виконаних робіт.',
        likes: 12,
      },
      {
        id: 2,
        author: 'Олександр П.',
        date: '15 березня 2026, 16:45',
        text: 'А коли буде проведено перевірку якості робіт? Чи можна буде оглянути дах?',
        likes: 5,
      },
      {
        id: 3,
        author: 'Голова ОСББ',
        date: '15 березня 2026, 17:20',
        text: 'Олександре, перевірка вже проведена комісією. Якщо бажаєте оглянути дах особисто — зверніться до мене, домовимося про час.',
        likes: 8,
      },
    ],
  },
  {
    id: 2,
    title: 'Пропозиції щодо благоустрою двору',
    author: 'Олександр П.',
    date: '10 березня 2026',
    views: 89,
    category: 'Благоустрій',
    lastReply: '5 годин тому',
    content: 'Пропоную встановити в дворі лавочки та висадити квіти. Також було б чудово встановити дитячий майданчик. Що думаєте?',
    replies: [
      {
        id: 1,
        author: 'Ірина В.',
        date: '10 березня 2026, 12:15',
        text: 'Підтримую! Особливо щодо лавочок. Можна також поставити сміттєві урни.',
        likes: 15,
      },
      {
        id: 2,
        author: 'Володимир С.',
        date: '10 березня 2026, 14:30',
        text: 'Дитячий майданчик — це добре, але треба подумати про безпеку. Може спочатку відремонтуємо огорожу?',
        likes: 7,
      },
      {
        id: 3,
        author: 'Голова ОСББ',
        date: '11 березня 2026, 09:00',
        text: 'Дякую за пропозиції! Внесу питання благоустрою до порядку денного наступних зборів. Прошу всіх бажаючих підготувати конкретні пропозиції з кошторисом.',
        likes: 20,
      },
    ],
  },
  {
    id: 3,
    title: 'Тарифи на комунальні послуги — обговорення',
    author: 'Ірина В.',
    date: '5 березня 2026',
    views: 234,
    category: 'Фінанси',
    lastReply: '1 день тому',
    content: 'Чому так виросли тарифи на воду? Хтось може пояснити?',
    replies: [
      {
        id: 1,
        author: 'Петро М.',
        date: '5 березня 2026, 11:20',
        text: 'Це не ОСББ підвищило тарифи, а облводоканал. Ми лише перераховуємо платежі.',
        likes: 18,
      },
      {
        id: 2,
        author: 'Голова ОСББ',
        date: '5 березня 2026, 13:45',
        text: 'Ірино, тарифи встановлюються НКРЕКП. ОСББ не має впливу на ці ціни. Але ми моніторимо споживання і намагаємося оптимізувати витрати.',
        likes: 25,
      },
      {
        id: 3,
        author: 'Марія К.',
        date: '6 березня 2026, 10:15',
        text: 'Можна встановити загальнобудинковий лічильник, щоб платити за фактичне споживання, а не за нормативами.',
        likes: 14,
      },
    ],
  },
  {
    id: 4,
    title: 'Проблеми з паркуванням у дворі',
    author: 'Володимир С.',
    date: '1 березня 2026',
    views: 312,
    category: 'Паркування',
    lastReply: '3 дні тому',
    content: 'Чужі машини постійно паркуються у нашому дворі. Чи можна встановити шлагбаум?',
    replies: [
      {
        id: 1,
        author: 'Олександр П.',
        date: '1 березня 2026, 18:30',
        text: 'Підтримую! Вже набридло шукати місце для свого авто.',
        likes: 22,
      },
      {
        id: 2,
        author: 'Голова ОСББ',
        date: '2 березня 2026, 09:15',
        text: 'Володимире, питання вивчається. Для встановлення шлагбаума потрібен дозвіл та рішення зборів. Також треба продумати систему доступу для мешканців та екстрених служб.',
        likes: 16,
      },
      {
        id: 3,
        author: 'Ірина В.',
        date: '2 березня 2026, 14:20',
        text: 'Можна спочатку спробувати домовитися з сусідніми будинками про спільний паркинг?',
        likes: 9,
      },
      {
        id: 4,
        author: 'Голова ОСББ',
        date: '3 березня 2026, 10:00',
        text: 'Добра ідея, Ірино! Звернуся до голів сусідніх ОСББ для обговорення.',
        likes: 12,
      },
    ],
  },
  {
    id: 5,
    title: 'Запрошуємо на день відкритих дверей',
    author: 'Голова ОСББ',
    date: '28 лютого 2026',
    views: 178,
    category: 'Оголошення',
    lastReply: '5 днів тому',
    content: 'Шановні мешканці! Запрошуємо всіх на День відкритих дверей 15 березня о 14:00. Обговоримо плани на рік та відповімо на ваші запитання.',
    replies: [
      {
        id: 1,
        author: 'Марія К.',
        date: '28 лютого 2026, 16:00',
        text: 'Чи буде розглядатися питання ремонту під\'їздів?',
        likes: 8,
      },
      {
        id: 2,
        author: 'Голова ОСББ',
        date: '28 лютого 2026, 17:30',
        text: 'Так, Маріє! Питання ремонту під\'їздів включено до порядку денного.',
        likes: 10,
      },
    ],
  },
];

export function Forum() {
  const [topics, setTopics] = useState<Topic[]>(initialTopics);
  const [selectedTopic, setSelectedTopic] = useState<Topic | null>(null);
  const [newTopicTitle, setNewTopicTitle] = useState('');
  const [newTopicContent, setNewTopicContent] = useState('');
  const [newReply, setNewReply] = useState('');
  const [showNewTopicForm, setShowNewTopicForm] = useState(false);

  const handleCreateTopic = () => {
    if (newTopicTitle.trim() && newTopicContent.trim()) {
      const newTopic: Topic = {
        id: topics.length + 1,
        title: newTopicTitle,
        author: 'Ви',
        date: new Date().toLocaleDateString('uk-UA', { day: 'numeric', month: 'long', year: 'numeric' }),
        views: 0,
        category: 'Загальне',
        lastReply: 'щойно',
        content: newTopicContent,
        replies: [],
      };
      setTopics([newTopic, ...topics]);
      setNewTopicTitle('');
      setNewTopicContent('');
      setShowNewTopicForm(false);
    }
  };

  const handleAddReply = () => {
    if (newReply.trim() && selectedTopic) {
      const reply: Reply = {
        id: selectedTopic.replies.length + 1,
        author: 'Ви',
        date: new Date().toLocaleDateString('uk-UA', { day: 'numeric', month: 'long', year: 'numeric' }) + ', ' + new Date().toLocaleTimeString('uk-UA', { hour: '2-digit', minute: '2-digit' }),
        text: newReply,
        likes: 0,
      };
      const updatedTopic = { ...selectedTopic, replies: [...selectedTopic.replies, reply] };
      setSelectedTopic(updatedTopic);
      setTopics(topics.map(t => t.id === selectedTopic.id ? updatedTopic : t));
      setNewReply('');
    }
  };

  const totalReplies = topics.reduce((sum, t) => sum + t.replies.length, 0);

  return (
    <div className="container py-12">
      <div className="max-w-5xl mx-auto">
        <h1 className="text-4xl font-bold mb-4">Форум</h1>
        <p className="text-muted-foreground mb-8">Обговорення питань мешканців будинку</p>

        {!selectedTopic ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Topics List */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <MessageSquare className="h-5 w-5" />
                    Останні теми
                  </CardTitle>
                  <Button onClick={() => setShowNewTopicForm(true)}>
                    <MessageCircle className="h-4 w-4 mr-2" />
                    Нова тема
                  </Button>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {topics.map((topic) => (
                      <div 
                        key={topic.id} 
                        className="p-4 border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors"
                        onClick={() => setSelectedTopic(topic)}
                      >
                        <div className="flex items-start justify-between mb-2">
                          <h3 className="font-semibold hover:text-primary">{topic.title}</h3>
                          <Badge variant="secondary">{topic.category}</Badge>
                        </div>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <User className="h-3 w-3" />
                            {topic.author}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {topic.date}
                          </span>
                          <span className="flex items-center gap-1">
                            <MessageSquare className="h-3 w-3" />
                            {topic.replies.length} відповідей
                          </span>
                          <span className="flex items-center gap-1">
                            <Eye className="h-3 w-3" />
                            {topic.views} переглядів
                          </span>
                        </div>
                        <div className="mt-2 text-xs text-muted-foreground">
                          Остання відповідь: {topic.lastReply}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Статистика</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Тем</span>
                      <span className="font-semibold">{topics.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Повідомлень</span>
                      <span className="font-semibold">{totalReplies}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Користувачів</span>
                      <span className="font-semibold">89</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Правила форуму</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li>• Поважайте інших учасників</li>
                    <li>• Не використовуйте нецензурну лексику</li>
                    <li>• Створюйте теми у відповідних розділах</li>
                    <li>• Не розміщуйте рекламу</li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        ) : (
          /* Topic Detail View */
          <div>
            <Button 
              variant="ghost" 
              className="mb-4"
              onClick={() => setSelectedTopic(null)}
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Назад до списку
            </Button>

            <Card className="mb-6">
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <Badge variant="secondary" className="mb-2">{selectedTopic.category}</Badge>
                    <h2 className="text-2xl font-bold">{selectedTopic.title}</h2>
                  </div>
                </div>
                <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                  <span className="flex items-center gap-1">
                    <User className="h-4 w-4" />
                    {selectedTopic.author}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    {selectedTopic.date}
                  </span>
                </div>
                <div className="prose max-w-none">
                  <p>{selectedTopic.content}</p>
                </div>
              </CardContent>
            </Card>

            <h3 className="text-xl font-semibold mb-4">
              Відповіді ({selectedTopic.replies.length})
            </h3>

            <div className="space-y-4 mb-6">
              {selectedTopic.replies.map((reply) => (
                <Card key={reply.id}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="bg-primary/10 p-2 rounded-full">
                          <User className="h-4 w-4 text-primary" />
                        </div>
                        <span className="font-semibold">{reply.author}</span>
                      </div>
                      <span className="text-xs text-muted-foreground">{reply.date}</span>
                    </div>
                    <p className="text-sm ml-10">{reply.text}</p>
                    <div className="flex items-center gap-2 mt-3 ml-10">
                      <Button variant="ghost" size="sm">
                        <ThumbsUp className="h-4 w-4 mr-1" />
                        {reply.likes}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Додати відповідь</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Textarea 
                    placeholder="Напишіть вашу відповідь..."
                    value={newReply}
                    onChange={(e) => setNewReply(e.target.value)}
                    rows={4}
                  />
                  <Button onClick={handleAddReply} className="w-full">
                    <Send className="h-4 w-4 mr-2" />
                    Надіслати відповідь
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* New Topic Dialog */}
        <Dialog open={showNewTopicForm} onOpenChange={setShowNewTopicForm}>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>Створити нову тему</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 mt-4">
              <div>
                <label className="text-sm font-medium mb-1 block">Заголовок</label>
                <Input 
                  placeholder="Тема обговорення..."
                  value={newTopicTitle}
                  onChange={(e) => setNewTopicTitle(e.target.value)}
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">Повідомлення</label>
                <Textarea 
                  placeholder="Опишіть ваше питання або пропозицію..."
                  value={newTopicContent}
                  onChange={(e) => setNewTopicContent(e.target.value)}
                  rows={5}
                />
              </div>
              <Button onClick={handleCreateTopic} className="w-full">
                Створити тему
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}