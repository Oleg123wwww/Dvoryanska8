import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Phone, Droplets, Zap, Flame, Trash2, User, Car, TreePine, Bug, Wrench, Paintbrush, Shield } from 'lucide-react';

const services = [
  { 
    icon: Phone, 
    title: 'Аварійна служба ОСББ', 
    description: 'Термінове усунення аварійних ситуацій у будинку', 
    contact: '+38 (099) 630-52-65', 
    badge: 'Терміново', 
    badgeColor: 'bg-red-500',
    hours: 'Цілодобово' 
  },
  { 
    icon: Droplets, 
    title: 'Водопостачання', 
    description: 'Обслуговування систем водопостачання та водовідведення', 
    contact: '0-800-505-505', 
    hours: 'Пн-Пт: 08:00-17:00' 
  },
  { 
    icon: Zap, 
    title: 'Електропостачання', 
    description: 'Обслуговування електромереж та електрообладнання', 
    contact: '0-800-505-505', 
    hours: 'Цілодобово' 
  },
  { 
    icon: Flame, 
    title: 'Газопостачання', 
    description: 'Обслуговування газових мереж та обладнання', 
    contact: '104', 
    badge: 'Терміново', 
    badgeColor: 'bg-red-500',
    hours: 'Цілодобово' 
  },
  { 
    icon: Trash2, 
    title: 'Вивезення сміття', 
    description: 'Регулярне вивезення твердих побутових відходів', 
    contact: '+38 (048) 705-67-93', 
    hours: 'Пн, Ср, Пт: 08:00-12:00' 
  },
  { 
    icon: User, 
    title: 'Голова ОСББ', 
    description: 'Загальні питання щодо управління будинком', 
    contact: '+38 (099) 630-52-65', 
    hours: 'Пн-Пт: 09:00-18:00' 
  },
  { 
    icon: Car, 
    title: 'Паркування', 
    description: 'Організація паркування на прибудинковій території', 
    contact: '+38 (099) 630-52-65', 
    hours: 'Пн-Пт: 09:00-18:00' 
  },
  { 
    icon: TreePine, 
    title: 'Благоустрій', 
    description: 'Догляд за прибудинковою територією та озелененням', 
    contact: '+38 (099) 630-52-65', 
    hours: 'Пн-Пт: 09:00-18:00' 
  },
  { 
    icon: Bug, 
    title: 'Дезінсекція', 
    description: 'Боротьба з комахами та гризунами', 
    contact: '+38 (048) 705-67-95', 
    hours: 'За попереднім записом' 
  },
];

const additionalServices = [
  { icon: Wrench, title: 'Ремонтні роботи', description: 'Поточний та капітальний ремонт приміщень' },
  { icon: Paintbrush, title: 'Фарбування', description: 'Фарбування фасаду, під\'їздів, огорож' },
  { icon: Shield, title: 'Охорона', description: 'Контроль доступу та відеоспостереження' },
];

const emergencyNumbers = [
  { number: '101', label: 'Пожежна' },
  { number: '102', label: 'Поліція' },
  { number: '103', label: 'Швидка' },
  { number: '104', label: 'Газова' },
];

export function Services() {
  return (
    <div className="container py-12">
      <div className="max-w-5xl mx-auto">
        <h1 className="text-4xl font-bold mb-4">Послуги</h1>
        <p className="text-muted-foreground mb-8">Комунікації та служби, що обслуговують наш будинок</p>

        <h2 className="text-2xl font-bold mb-4">Основні служби</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <Card key={index} className="relative">
                {service.badge && (
                  <Badge className={`absolute top-3 right-3 ${service.badgeColor} text-white`}>
                    {service.badge}
                  </Badge>
                )}
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="bg-primary/10 p-2 rounded-lg">
                      <Icon className="h-5 w-5 text-primary" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-semibold text-sm mb-1">{service.title}</h4>
                      <p className="text-xs text-muted-foreground mb-2">{service.description}</p>
                      <a href={`tel:${service.contact}`} className="text-sm text-primary hover:underline block">
                        {service.contact}
                      </a>
                      <p className="text-xs text-muted-foreground mt-1">{service.hours}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <h2 className="text-2xl font-bold mb-4">Додаткові послуги</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          {additionalServices.map((service, index) => {
            const Icon = service.icon;
            return (
              <Card key={index}>
                <CardContent className="p-4 flex items-start gap-4">
                  <div className="bg-primary/10 p-3 rounded-lg">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">{service.title}</h4>
                    <p className="text-sm text-muted-foreground">{service.description}</p>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <h2 className="text-2xl font-bold mb-4">Екстрені служби</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {emergencyNumbers.map((item, index) => (
            <Card key={index} className="text-center bg-red-50 border-red-200">
              <CardContent className="p-4">
                <a href={`tel:${item.number}`} className="text-2xl font-bold text-red-600 hover:underline block mb-1">
                  {item.number}
                </a>
                <p className="text-sm text-muted-foreground">{item.label}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}