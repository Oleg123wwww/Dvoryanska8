import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Droplets, Zap, Trash2, Thermometer } from 'lucide-react';

const tariffs = [
  { icon: Droplets, name: 'Холодне водопостачання', unit: '21.50 грн/м³', note: 'За нормативом споживання' },
  { icon: Droplets, name: 'Водовідведення', unit: '20.80 грн/м³', note: 'За нормативом споживання' },
  { icon: Zap, name: 'Електропостачання', unit: '2.88 грн/кВт·год', note: 'За нормативом споживання' },
  { icon: Thermometer, name: 'Опалення', unit: '38.90 грн/м²', note: 'За нормативом споживання' },
  { icon: Trash2, name: 'Вивезення ТПВ', unit: 'від 48.00 грн/міс', note: 'За одного мешканця' },
];

const budgetItems = [
  { name: 'Утримання будинку (прибирання)', amount: '120 000 грн' },
  { name: 'Електроенергія (МОП)', amount: '85 000 грн' },
  { name: 'Водопостачання (МОП)', amount: '45 000 грн' },
  { name: 'Ремонтні роботи', amount: '150 000 грн' },
  { name: 'Технічне обслуговування ліфта', amount: '35 000 грн' },
  { name: 'Дезінсекція/дератизація', amount: '12 000 грн' },
  { name: 'Благоустрій прибудинкової території', amount: '25 000 грн' },
  { name: 'Непередбачені витрати', amount: '13 000 грн' },
];

export function Finance() {
  return (
    <div className="container py-12">
      <div className="max-w-5xl mx-auto">
        <h1 className="text-4xl font-bold mb-4">Фінансова звітність</h1>
        <p className="text-muted-foreground mb-8">Прозорість фінансів — відкрита інформація про тарифи, надходження та витрати ОСББ</p>

        <Tabs defaultValue="tariffs" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="tariffs">Тарифи</TabsTrigger>
            <TabsTrigger value="budget">Кошторис</TabsTrigger>
            <TabsTrigger value="reports">Звіти</TabsTrigger>
          </TabsList>

          <TabsContent value="tariffs">
            <Card>
              <CardHeader>
                <CardTitle>Тарифи на комунальні послуги</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {tariffs.map((tariff, index) => {
                    const Icon = tariff.icon;
                    return (
                      <div key={index} className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                        <div className="flex items-center gap-4">
                          <div className="bg-primary/10 p-3 rounded-lg">
                            <Icon className="h-5 w-5 text-primary" />
                          </div>
                          <div>
                            <p className="font-medium">{tariff.name}</p>
                            <p className="text-sm text-muted-foreground">{tariff.note}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-xl font-bold text-primary">{tariff.unit}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
                <p className="text-xs text-muted-foreground mt-4">
                  * Тарифи встановлено відповідно до постанов НКРЕКП та рішень міської ради (станом на 2026 рік)
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="budget">
            <Card>
              <CardHeader>
                <CardTitle>Кошторис на 2026 рік</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {budgetItems.map((item, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border-b last:border-0">
                      <span className="text-muted-foreground">{item.name}</span>
                      <span className="font-semibold">{item.amount}</span>
                    </div>
                  ))}
                  <div className="flex items-center justify-between p-4 bg-primary/5 rounded-lg mt-4">
                    <span className="font-bold">ВСЬОГО</span>
                    <span className="text-xl font-bold text-primary">485 000 грн</span>
                  </div>
                </div>
                <div className="mt-6 p-4 bg-muted/50 rounded-lg">
                  <p className="text-sm text-muted-foreground">
                    <strong>Затверджено:</strong> на загальних зборах 15 березня 2026 року
                  </p>
                  <p className="text-sm text-muted-foreground">
                    <strong>Голова ОСББ:</strong> Здрок О.В.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reports">
            <Card>
              <CardHeader>
                <CardTitle>Фінансові звіти</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { period: 'Січень 2026', status: 'Опубліковано', date: '05.02.2026' },
                    { period: 'Лютий 2026', status: 'Опубліковано', date: '05.03.2026' },
                    { period: 'Березень 2026', status: 'Опубліковано', date: '05.04.2026' },
                    { period: 'I квартал 2026', status: 'Опубліковано', date: '10.04.2026' },
                    { period: '2025 рік', status: 'Опубліковано', date: '15.01.2026' },
                  ].map((report, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <p className="font-medium">Звіт за {report.period}</p>
                        <p className="text-sm text-muted-foreground">Опубліковано: {report.date}</p>
                      </div>
                      <Badge variant="secondary">{report.status}</Badge>
                    </div>
                  ))}
                </div>
                <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <p className="text-sm text-blue-800">
                    Фінансові звіти публікуються щомісяця до 5 числа наступного місяця. 
                    Річний звіт публікується до 15 січня наступного року.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}